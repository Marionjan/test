var searchData=
[
  ['client_2ejava_125',['Client.java',['../Client_8java.html',1,'']]],
  ['createdialog_2ejava_126',['CreateDialog.java',['../CreateDialog_8java.html',1,'']]]
];
