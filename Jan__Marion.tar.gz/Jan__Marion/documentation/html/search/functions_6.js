var searchData=
[
  ['isclosed_169',['isClosed',['../classSocket.html#af82b21921f44a5c210f8aaedc26ca1c3',1,'Socket::isClosed()'],['../classServerSocket.html#aa1c00353c8f50697c8a4a8882e520286',1,'ServerSocket::isClosed()']]]
];
