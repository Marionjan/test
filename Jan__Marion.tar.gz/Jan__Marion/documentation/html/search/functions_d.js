var searchData=
[
  ['video_210',['Video',['../classVideo.html#ab67336c2c5b6227a9635bc7dcd6af543',1,'Video::Video()'],['../classVideo.html#a53b09944ac2adac1a37c7e36fb42befc',1,'Video::Video(std::string name, std::string pathname, int duration)']]]
];
