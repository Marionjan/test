var searchData=
[
  ['film_22',['Film',['../classFilm.html',1,'Film'],['../classFilm.html#af2835db2b0ef3a87aaa3222f4d9d1ae3',1,'Film::Film()'],['../classFilm.html#a6fd592387635501e2e8eab2df28c74bf',1,'Film::Film(std::string name, std::string pathname, int duration, int *chapters, int nbChapters)']]],
  ['film_2ecpp_23',['Film.cpp',['../Film_8cpp.html',1,'']]],
  ['film_2eh_24',['Film.h',['../Film_8h.html',1,'']]]
];
