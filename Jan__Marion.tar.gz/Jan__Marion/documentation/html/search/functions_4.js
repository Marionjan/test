var searchData=
[
  ['film_154',['Film',['../classFilm.html#af2835db2b0ef3a87aaa3222f4d9d1ae3',1,'Film::Film()'],['../classFilm.html#a6fd592387635501e2e8eab2df28c74bf',1,'Film::Film(std::string name, std::string pathname, int duration, int *chapters, int nbChapters)']]]
];
