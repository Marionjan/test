var searchData=
[
  ['video_94',['Video',['../classVideo.html',1,'Video'],['../classVideo.html#ab67336c2c5b6227a9635bc7dcd6af543',1,'Video::Video()'],['../classVideo.html#a53b09944ac2adac1a37c7e36fb42befc',1,'Video::Video(std::string name, std::string pathname, int duration)']]],
  ['video_2eh_95',['Video.h',['../Video_8h.html',1,'']]]
];
